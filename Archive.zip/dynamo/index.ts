import { RemovalPolicy } from "aws-cdk-lib";
import { AttributeType, BillingMode, StreamViewType, Table } from "aws-cdk-lib/aws-dynamodb";
import { Construct } from "constructs";

export const getDiningReservationTable = (scope: Construct, AppName: string) => {
    const diningReservation = new Table(
        scope,
        `nx-${AppName}-falcon-mcs-table-booking`,
        {
          partitionKey: { name: 'id', type: AttributeType.STRING },
          sortKey: { name: 'date_time', type: AttributeType.STRING },
          billingMode:  BillingMode.PAY_PER_REQUEST,
          // readCapacity: AppName != 'PROD' ? 25 : undefined,
          // writeCapacity: AppName != 'PROD' ? 25 : undefined,
          removalPolicy: AppName != 'PROD' ?  RemovalPolicy.DESTROY : RemovalPolicy.RETAIN
        }
    )

    diningReservation.addGlobalSecondaryIndex({
      indexName: 'GI_store_phone',
      partitionKey: {
        name: 'legacy_store_id',
        type: AttributeType.NUMBER,
      },
      sortKey: {
        name: 'phone',
        type: AttributeType.STRING,
      },
    })

    return diningReservation
}