export const succes = () => {
    return "Success"
}