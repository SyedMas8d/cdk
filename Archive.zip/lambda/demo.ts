// import { v4 as uuidv4 } from 'uuid';
import {success, fail} from "response_d"

export const handler = async (_event: any) => {
    
    console.log("===============")
    console.log(success())
    console.log("===============")
    console.log(fail())
    try {
        return {
            statusCode : 200,
            body: JSON.stringify({message: success()})
        }
    }
    catch(e) {
        return {
            statusCode : 200,
            body: JSON.stringify({message: fail()})
        }
    }
    
}

// export const getAllConsumer = async (_evnt: any) => {
//     try {
//         return {
//             statusCode: 200,
//             body: JSON.stringify({message: "success"})
//         }
//     }
//     catch(e) {
//         return {
//             statusCode: 500,
//             body: JSON.stringify({message: 'Server Issue'})
//         }
//     }
// }