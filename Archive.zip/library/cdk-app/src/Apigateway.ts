import { NestedStack, Stack, StackProps } from "aws-cdk-lib";
import { Construct } from "constructs";
import { RestApi, ResourceBase, IRestApi } from "aws-cdk-lib/aws-apigateway";
import {StringParameter} from 'aws-cdk-lib/aws-ssm'

interface ApigatewayProps {
    apiGatewayName: string
}

export class Apigateway extends Construct {
    public readonly RestApi: IRestApi
    constructor(scope: Construct, id: string, props: ApigatewayProps) {
        super(scope, id)
        
        // const apiId: string = StringParameter.fromStringParameterName(this,'falconMcsApiArn',`/${props.apiGatewayName}/RestApiId`).stringValue;
        // const apiRootResourceId: string = StringParameter.fromStringParameterName(this,'falconMcsApiRootArn',`/${props.apiGatewayName}/RootResourceId`).stringValue;

        // this.RestApi =  RestApi.fromRestApiAttributes(this,`${props.apiGatewayName}Api`, {restApiId: apiId, rootResourceId: apiRootResourceId});
    }

    // public getApigatewayResource(path: string): ResourceBase {
    //     const endPoints = path.split('/')
    //     let currentPath = this.RestApi.root
    
    //     for (const endPoint of endPoints) {
    //       currentPath =
    //         currentPath.getResource(endPoint) ?? currentPath.addResource(endPoint)
    //     }
    
    //     return currentPath as ResourceBase
    // }
}