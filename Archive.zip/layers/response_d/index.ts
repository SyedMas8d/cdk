// import {v4} from  'uuid'
export const success = () => {
    return "Success"
}

export const fail = () => {
    return "Fails"
}