import { LambdaIntegration, ResourceBase, Resource, RestApi, IRestApi } from "aws-cdk-lib/aws-apigateway";
import { Construct } from "constructs";
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs'
import { Architecture, Code, ILayerVersion, LayerVersion, Runtime } from 'aws-cdk-lib/aws-lambda';
import { Duration, Stack } from "aws-cdk-lib";

import { Apigateway } from './Apigateway'
import {lambdaConfigInterface, lambdaConfiguration} from './config'
import { CdkLayer } from './layers'

import { RootApiGatewayStack } from './RootApiGatewayStack'

import { DynamoAccess } from '@cdk/cdk-app'


interface ApigatewayProps {
    apiGateway: RootApiGatewayStack,
    version?: string
}


export class Api {
    // public readonly apigateway: Apigateway
    public readonly scope: Construct
    public lambdaConfig: lambdaConfigInterface
    public apiGatewayStack: RootApiGatewayStack
    public RestApi: IRestApi
    public version: string
    public layers: ILayerVersion[]=[]

    constructor(scope: Construct, props:ApigatewayProps, lambdaConfig?: lambdaConfigInterface) {
        // super(scope, `${Stack.of(scope).stackName}-Apigateway-Constructs`, props)
        this.scope = scope
        this.lambdaConfig = lambdaConfig ? lambdaConfig : lambdaConfiguration()
        this.apiGatewayStack = props.apiGateway
        this.version = props.version || ''

        this.RestApi = RestApi.fromRestApiAttributes(
            this.scope,
            `public-consumer-demo-${this.version}`,
            {
              restApiId: props.apiGateway.restApiId,
              rootResourceId: props.apiGateway.restApiRootResourceId,
            }
        )

        if(this.lambdaConfig.layers) {

            for(let layerCode of this.lambdaConfig.layers) {
                
                const layer = new LayerVersion(
                    this.scope,
                    `${Stack.of(this.scope).stackName}/${layerCode}`,
                    {
                        code: Code.fromAsset(
                            layerCode
                        ),
                        compatibleRuntimes: [Runtime.NODEJS_14_X],
                        compatibleArchitectures: [Architecture.X86_64],
                    }
                )
    
                this.layers.push(layer)
            }

            // After layer attached make lambda layers as undefined
            this.lambdaConfig.layers = undefined  
        }
    }

    get(path: string, lambdaCode: string, lambdaConfig?: lambdaConfigInterface) {
        this.attachApiToLambda(path, lambdaCode, 'GET', lambdaConfig)
    }

    post(path: string, lambdaCode: string, lambdaConfig?: lambdaConfigInterface) {
        this.attachApiToLambda(path, lambdaCode, 'POST', lambdaConfig)
    }

    put(path: string, lambdaCode: string, lambdaConfig?: lambdaConfigInterface) {
        this.attachApiToLambda(path, lambdaCode, 'PUT', lambdaConfig)
    }

    delete(path: string, lambdaCode: string, lambdaConfig?: lambdaConfigInterface) {
        this.attachApiToLambda(path, lambdaCode, 'DELETE', lambdaConfig)
    }
    

    attachApiToLambda(path: string, lambdaCode: string, method: string, lambdaConfig?: lambdaConfigInterface) {
        
        if(this.version !== '') path = `${this.version}/${path}`
        
        const apiResource = this.apiGatewayStack.getApigatewayResource(path)

        const api = Resource.fromResourceAttributes(
            this.scope,
            `${method}-${path}`,
            {
              restApi: this.RestApi,
              resourceId: apiResource.resourceId,
              path: `/${path}`,
            }
        )

        if(lambdaConfig) api.addMethod(method, new LambdaIntegration(this.getLambdaResource(lambdaCode, `${method}-${path}-lambda`, lambdaConfig)))
        else api.addMethod(method, new LambdaIntegration(this.getLambdaResource(lambdaCode, `${method}-${path}-lambda`)))
    }

    getLambdaResource(lambdaCodePath: string, suffix: string, lambdaConfig?:lambdaConfigInterface): NodejsFunction {

        this.lambdaConfig = (lambdaConfig) ? lambdaConfig: this.lambdaConfig

        const lambda = new NodejsFunction(
            this.scope,
            `masood-workshop-lambda-${suffix}`,
            {
              memorySize: (this.lambdaConfig && this.lambdaConfig.memorySize) ?
                            this.lambdaConfig.memorySize : lambdaConfiguration().memorySize,
              timeout: (this.lambdaConfig && this.lambdaConfig.timeout) ? 
                            Duration.seconds(this.lambdaConfig.timeout) : 
                            Duration.seconds(lambdaConfiguration().timeout),
              runtime: (this.lambdaConfig && this.lambdaConfig.runtime) ?
                            this.lambdaConfig.runtime : lambdaConfiguration().runtime,
              handler: 'handler',
              entry: lambdaCodePath,
              bundling: {
                externalModules: ['aws-sdk', 'response_d'],
              }
            }
        )
        
        // if(this.lambdaConfig.layers) {

        //     for(let layerCode of this.lambdaConfig.layers) {
                
        //         const layer = new LayerVersion(
        //             this.scope,
        //             `${Stack.of(this.scope).stackName}/${layerCode}`,
        //             {
        //                 code: Code.fromAsset(
        //                     layerCode
        //                 ),
        //                 compatibleRuntimes: [Runtime.NODEJS_14_X],
        //                 compatibleArchitectures: [Architecture.X86_64],
        //             }
        //         )
    
        //         lambda.addLayers(layer)
        //     }
        // }

        // if(this.layers && this.layers.length) {
        //     for(let layer of this.layers) lambda.addLayers(layer)
        // }

        if(this.lambdaConfig.layerVersn && this.lambdaConfig.layerVersn.length) {
            for(let layerVrn of this.lambdaConfig.layerVersn) lambda.addLayers(layerVrn)
        }

        if(this.lambdaConfig.dynamoTables) {

            for(let dynamo of this.lambdaConfig.dynamoTables) {
                
                if(dynamo.access === DynamoAccess.READ) dynamo.table.grantReadData(lambda)

                if(dynamo.access === DynamoAccess.WRITE) dynamo.table.grantReadWriteData(lambda)

                if(dynamo.access === DynamoAccess.FULL) dynamo.table.grantFullAccess(lambda)
            }
        }

        return lambda
    }
}
