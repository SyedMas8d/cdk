import { Duration, Stack, StackProps } from 'aws-cdk-lib';
import * as sns from 'aws-cdk-lib/aws-sns';
import * as subs from 'aws-cdk-lib/aws-sns-subscriptions';
import * as sqs from 'aws-cdk-lib/aws-sqs';
import { Construct } from 'constructs';

import { CdkStackProps, nativeBundle } from '@cdk/cdk-app'
import { Api } from '@cdk/cdk-app';

import {join} from 'path'
import {getDiningReservationTable} from '../dynamo/index'

export class CdkAppDemoStack extends Stack {
  constructor(scope: Construct, id: string, props: CdkStackProps) {
    super(scope, id, props);
    const dinningTble = getDiningReservationTable(this, 'masood')

    // const queue = new sqs.Queue(this, 'CdkAppDemoQueue', {
    //   visibilityTimeout: Duration.seconds(300)
    // });

    // const topic = new sns.Topic(this, 'CdkAppDemoTopic');

    // topic.addSubscription(new subs.SqsSubscription(queue));

    const layerCode = join(__dirname, '../layers/test.ts')
    const rootPath = join(__dirname, '../package-lock.json')
    const depsLockFilePath = join(__dirname, '../')

    // const assetCode = nativeBundle(layerCode, rootPath, depsLockFilePath)

    const api = new Api(this, {apiGateway: props.apiGateway})

    api.get('v1/test', join(__dirname, '../lambda/demo.ts'))
    api.get('v1/test1', join(__dirname, '../lambda/demo.ts'))

    // const apiV2 = new Api(this, {apiGateway: props.apiGateway, version: 'v2'})

    // apiV2.get('test', join(__dirname, '../lambda/demo.ts'))
  }
}
