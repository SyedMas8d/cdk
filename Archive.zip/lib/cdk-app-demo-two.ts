import { Api, CdkStackProps } from "@cdk/cdk-app";
import { Stack } from "aws-cdk-lib";
import { Construct } from "constructs";
import { join } from 'path'
import { getDiningReservationTable } from '../dynamo'
import { lambdaConfiguration, DynamoAccess, addLayer } from "@cdk/cdk-app";
import { CfnMultiRegionAccessPoint } from "aws-cdk-lib/aws-s3";

export class DemoStackTwo extends Stack {
    constructor(scope: Construct, id: string, props: CdkStackProps) {
        super(scope, id, props)

        const layerCode = addLayer(this, 'nithan')
        const masoodL = addLayer(this, 'falcon_runtime')

        const dinningTble = getDiningReservationTable(this, 'masood')

        const gloablLambdaConfig = lambdaConfiguration(
            {

                dynamoTables: [
                    {
                        table: dinningTble,
                        access: DynamoAccess.FULL
                    }
                ]

            }
        )

        const demoGetLambdaConfig = lambdaConfiguration(
            {
                layerVersn: [layerCode, masoodL]
            }
        )

        const apiV1 = new Api(this, { apiGateway: props.apiGateway, version: 'v1' }, gloablLambdaConfig)

        const demoLamb = apiV1.post('demo', join(__dirname, '../lambda/demo.ts'))
        apiV1.get('demo', join(__dirname, '../lambda/demo.ts'), gloablLambdaConfig)


        const apiV2 = new Api(this, { apiGateway: props.apiGateway, version: 'v2' }, gloablLambdaConfig)

        apiV2.get('demo', join(__dirname, '../lambda/demo.ts'))
    }
}