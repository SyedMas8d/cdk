export const d = () => {
    return "success"
}