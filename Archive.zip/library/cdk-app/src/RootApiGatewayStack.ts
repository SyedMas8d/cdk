import { Stack, StackProps } from "aws-cdk-lib";
import { ResourceBase, RestApi } from "aws-cdk-lib/aws-apigateway";
import { Construct } from "constructs";
import { StringParameter} from 'aws-cdk-lib/aws-ssm'

interface ApiStackProps extends StackProps {
    apiGatewayName: string
}

export class RootApiGatewayStack extends Stack {
    public RestApi: RestApi
    public restApiId: string
    public restApiRootResourceId: string


    constructor(scope: Construct, id: string, props: ApiStackProps) {
        super(scope, id, props)

        this.RestApi = new RestApi(this, props.apiGatewayName)
        this.RestApi.root.addMethod('ANY')

        this.restApiId = this.RestApi.restApiId
        
        this.restApiRootResourceId = this.RestApi.restApiRootResourceId
    }

    public getApigatewayResource(path: string): ResourceBase {
        const endPoints = path.split('/')
        let currentPath = this.RestApi.root
    
        for (const endPoint of endPoints) {
          currentPath =
            currentPath.getResource(endPoint) ?? currentPath.addResource(endPoint)
        }
    
        return currentPath as ResourceBase
    }
}