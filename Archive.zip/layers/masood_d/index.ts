export const successD = () => {
    return "Success";
}