export const success = () => {
    return "Success"
}

export const fail = () => {
    return "Fail"
}