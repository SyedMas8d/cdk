import { Architecture, Code, ILayerVersion, LayerVersion, Runtime } from 'aws-cdk-lib/aws-lambda'
import { Construct } from 'constructs'
import { build } from 'esbuild'
// import { resolve } from 'path'
import nodeExternals from 'esbuild-plugin-node-externals'
// import { Bundling } from 'aws-cdk-lib/aws-lambda-nodejs/lib/bundling'
import { Bundling } from './bundle'
import * as cdk from 'aws-cdk-lib'
import * as os from 'os'
import { resolve, join, basename, dirname } from 'path'
const isWindows = os.platform() === 'win32'
import * as fs from 'fs'
const { exec } = require('child_process')

export interface layerCreationInterface {
  code: string,
  layerName: string
}

export const addLayer  = (scope: Construct, layerCodeAsset: string): ILayerVersion => {
  
  return new LayerVersion(scope, `layer-code`, {
    code: Code.fromAsset(join(__dirname, `../../../bundler/${layerCodeAsset}`)),
    compatibleRuntimes: [Runtime.NODEJS_14_X],
    compatibleArchitectures: [Architecture.X86_64],
  })
}

export class CdkLayer {
    public readonly scope: Construct
    public projectRoot: string
    constructor(scope: Construct) {
        this.scope = scope
    }

    createLayers (layerDetails: layerCreationInterface[], nodeModules: string[]=[]): string[] {

        const layerCodePaths: string[] = []

        for(let layer of layerDetails) {
            build({
                entryPoints: [
                    layer.code,
                ],
                outdir: join(__dirname, `../../../dist/nodejs/${layer.layerName}`),
                platform: 'node',
                bundle: true,
                minify: true,
                target: 'node14',
                // plugins: [
                //     nodeExternals({
                //         include: ['axios'],
                //     }),
                // ],
            })

            layerCodePaths.push(join(__dirname, `../../../dist/nodejs/${layer.layerName}`))
        }
        

        return layerCodePaths;
    }
}

export const addLayers = (layerDetails: layerCreationInterface[], nodeModules: string[]=[]): string[] => {

    const layerCodePaths: string[] = []

    for(let layer of layerDetails) {
        build({
          entryPoints: [
              layer.code,
          ],
          outdir: join(__dirname, `../../../dist/${layer.layerName}`),
          platform: 'node',
          bundle: true,
          minify: true,
          target: 'node14',
        })

        layerCodePaths.push(join(__dirname, `../../../dist/${layer.layerName}`))
    }
    
    

    return layerCodePaths;
}

export const createLayer = (scope: Construct, layerDetails: layerCreationInterface): ILayerVersion[] => {

    let layers: ILayerVersion[]= [];

    (async () => {
        // const outDir = `../../../../../dist/layer/nodejs/${layerDetails.layerName}`
        await build({
          entryPoints: [
            layerDetails.code,
          ],
          outdir: join(__dirname, `../../../dist/layer/${layerDetails.layerName}/nodejs`),
          platform: 'node',
          bundle: true,
          minify: true,
          target: 'node14',
        })

        await createPackageFile(
          join(__dirname, `../../../dist/layer/${layerDetails.layerName}/nodejs/package.json`),
        //   FalconNodeJsLambda.defaultModulesToBundle
        )

        await installDependencies(
          join(__dirname, '../../../dist/layer/${layerDetails.layerName}/nodejs')
        )

        const layer = new LayerVersion(
          scope,
          `api-falcon-runtime-${layerDetails.layerName}`,
          {
            code: Code.fromAsset(
              join(__dirname, `../../../dist/layer/${layerDetails.layerName}`)
            ),
            compatibleRuntimes: [Runtime.NODEJS_14_X],
            compatibleArchitectures: [Architecture.X86_64],
          }
        )
        
        layers.push(layer)
    })()

    return layers
}

const createPackageFile = (filePath: string) =>
    new Promise((resolve, reject) => {
      try {
        const devDependencies: any = {}

        fs.writeFile(
          filePath,
          JSON.stringify({ devDependencies: devDependencies }),
          (err) => {
            if (err) {
              console.log('ERROR in Package JSON', err)
              reject('ERROR in Package JSON file')
            } else {
              resolve('Package JSON created')
            }
          }
        )
    } catch (error) {
        reject('ERROR in dir creation')
    }
})

let a = ['uuid']

const installDependencies = (path: string) =>
    
    new Promise((resolve, reject) => {
      const command = `cd ${path} && npm i ${a.join(
        ' '
      )}`
    exec(command, (err: any, output: any) => {
        if (err) {
          console.log('ERROR in installDependencies', err)
        }
        console.log('output', output)
        resolve('DONE')
    })
})

export const nativeBundle = (path: string, rootPath: string, depsLockFilePath: string) => {
  const falconRuntimeBundle = Bundling.bundle({
    architecture: Architecture.X86_64,
    runtime: Runtime.NODEJS_14_X,
    nodeModules: ['uuid'],
    externalModules: ['aws-sdk'],
    entry: path,
    projectRoot: rootPath,
    depsLockFilePath: depsLockFilePath,
    commandHooks: {
      beforeBundling: () => [],
      beforeInstall: () => [],
      /**
       * We need to update the final output structure for the lambda function
       * in order to correctly allow them to be imported by require()
       *
       * Lambda PATH variable includes /opt/nodejs/node_modules, however the bundle command
       * puts all files on /opt, so here we hook into the build step in order to restructure
       * the files and folders are in the correct place
       */
      afterBundling: (_, outputDir) => {
        return isWindows
          ? [
              `cd ${outputDir}`,
              `mkdir nodejs`,
              `mkdir nodejs\\falcon-runtime`,
              `move yarn.lock nodejs/`,
              `move package.json nodejs/`,
              `move node_modules nodejs/`,
              `move index.js nodejs\\falcon-runtime/`,
            ]
          : [
              `cd ${outputDir}`,
              `mkdir -p nodejs/falcon-runtime`,
              `mv node_modules package.json yarn.lock nodejs/`,
              `mv index.js nodejs/falcon-runtime`,
            ]
      },
    },
  })

  return falconRuntimeBundle
}