import path from 'path'

console.log(path)
const findwordBackForth = (word, word2) => {
    a = word.split('')
    b = word2.split('')

    let index = null

    for(let w of b) {
        word.slice(word.indexOf(w))
        if(index && word.indexOf(w) < index) {
            return "False"
        }

        index = word.indexOf(w);
    }

    return "True"
}

console.log(findwordBackForth("syedMas8d", "sas"))