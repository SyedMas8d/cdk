function masood(){
    return "success";
}

export {masood}