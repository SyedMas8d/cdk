export const success = () => {
    return "Success"
}