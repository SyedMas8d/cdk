import { StackProps } from "aws-cdk-lib"
import { Table } from "aws-cdk-lib/aws-dynamodb"
import { ILayerVersion, LayerVersion, Runtime } from "aws-cdk-lib/aws-lambda"
import { RootApiGatewayStack } from "."

export const ApiGatewayConfig = (apiGatewayName: string) =>  {
    return {apiGatewayName}
}

export interface CdkStackProps extends StackProps {
    apiGateway: RootApiGatewayStack
}

export const enum DynamoAccess {
    'READ',
    'WRITE',
    'FULL'
}

interface dynamoTable {
    table: Table,
    access: DynamoAccess
}

export interface lambdaConfigInterface {
    memorySize?: number,
    timeout?: number,
    runtime?: Runtime,
    layers?: string[],
    dynamoTables?: dynamoTable[],
    layerVersn?: ILayerVersion[] 
}

export const apiGatewayConfiguration = (apiGateway: RootApiGatewayStack) => {
    return {
        apiGateway
    }
}

export const lambdaConfiguration = (config?: lambdaConfigInterface) => {
    return {
        memorySize: config?.memorySize ?  config.memorySize : 218,
        timeout: config?.timeout ? config.timeout : 5, 
        runtime: config?.runtime ? config.runtime : Runtime.NODEJS_14_X,
        layers: config?.layers ? config.layers : undefined,
        dynamoTables: config?.dynamoTables ? config.dynamoTables : undefined,
        layerVersn: config?.layerVersn ? config.layerVersn : undefined
    }
}